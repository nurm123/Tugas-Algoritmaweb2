<?php
$nama = "Nurmansyah";
$nim = 2018804480;
$kelas = "SI Shift 2018";
$Kampus = "STMIK Insan Pembangunan F";
echo "Nama Mahasiswa : $nama";
echo "<br>";
echo "Nim Mahasiswa : $nim";
echo "<br>";
echo "Kelas : $kelas";
echo "<br>";
echo "Nama Kampus : $Kampus";
echo "<br>";

?>
