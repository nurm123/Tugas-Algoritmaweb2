<?php 
echo $_POST ["nama_barang"];
echo "<br>";
echo $_POST ["merek_barang"];
echo "<br>";
echo $_POST ["stok_barang"];
echo "<br>";
echo $_POST ["harga_barang"];
?>
